package com.smp.smpguide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App() {
    MaterialTheme {
        var query by remember { mutableStateOf("") }
        val templates = remember {
            mutableStateListOf(
                "Шаблон 1: Быстрый ответ",
                "Шаблон 2: Проверка статуса",
                "Шаблон 3: Ссылка на документ"
            )
        }

        Scaffold(
            topBar = {
                TopAppBar(title = { Text("SMPGuide") })
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Поиск по шаблонам") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { templates.add("Новый шаблон ${templates.size + 1}") },
                        modifier = Modifier.weight(1f)
                    ) { Text("Добавить") }

                    OutlinedButton(
                        onClick = { if (templates.isNotEmpty()) templates.removeLast() },
                        modifier = Modifier.weight(1f)
                    ) { Text("Удалить последний") }
                }

                Spacer(Modifier.height(16.dp))
                Text("Список (пока демо, дальше подключим Room и разделы/подразделы):", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                val filtered = remember(query, templates) {
                    if (query.isBlank()) templates.toList()
                    else templates.filter { it.contains(query, ignoreCase = true) }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered) { item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(item, style = MaterialTheme.typography.bodyLarge)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { /* later: copy to clipboard */ }) {
                                    Text("Быстро копировать (скоро)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
